const express = require('express');
const router = express.Router();
const db = require('../config/db');

router.get('/', (req, res) => {
    db.query('SELECT * FROM monitoring', (err, results) => {
        if (err) throw err;
        res.render('dashboard', { data: results });
    });
});

router.post('/', (req, res) => {
    const { jenisBita, kondisi } = req.body;
    
    const query = "INSERT INTO monitoring (jenisBita, kondisi) VALUES     (?, ?)";
    db.query(query, [jenisBita, kondisi], (err, result) => {
        if (err) throw err;
        res.redirect('/monitoring');
    });
});

router.post('/update/:id', (req, res) => {
    const { id } = req.params;
    const { jenisBita, kondisi } = req.body;

    const query = "UPDATE monitoring SET jenisBita = ?, kondisi = ? WHERE id = ?";
    db.query(query, [jenisBita, kondisi, id], (err, result) => {
        if (err) throw err;
        res.redirect('/monitoring');
    });
});

router.get('/delete/:id', (req, res) => {
    const { id } = req.params;

    const query = "DELETE FROM monitoring WHERE id = ?";
    db.query(query, [id], (err, result) => {
        if (err) throw err;
        res.redirect('/monitoring');
    });
});

router.get('/add', (req, res) => {
    res.render('addMonitoring');
});

module.exports = router;